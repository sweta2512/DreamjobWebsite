import { BrowserRouter, Routes, Link, Route } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// Importing toastify module
// {ToastContainer,toast} from 'react-toastify';

// Import toastify css file
//import 'react-toastify/dist/ReactToastify.css';

// toast-configuration method,
// it is compulsory method.
//toast.configure()
import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import "./style.css";
import SERVICES from "../../Services";
import apiCall from "../../Helper.js";
//toast.configure();
let RegistrationForm = () => {
  const [isFoodChecked, setIsFoodChecked] = useState(false);
  const [isMovieChecked, setIsMovieChecked] = useState(false);
  const [allValues, setAllValues] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    country: "",
    state: "",
    city: "",
    food: "",
    movie: "",
  });

  //handle when input value changes
  let handleChange = (e) => {
    //console.log({ ...allValues });
    // console.log("target event", e.target.value);
    //console.log("target event check", e.target.checked);

    //  console.log({ [e.target.name]: e.target.value });
    //console.log(allValues.username);
    if (e.target.name === "food") setIsFoodChecked(!isFoodChecked);
    if (e.target.name === "movie") setIsMovieChecked(!isMovieChecked);
    setAllValues({ ...allValues, [e.target.name]: e.target.value });
    //console.log(isChecked)
  };

  //handle form submit
  let handleSubmit = (e) => {
    e.preventDefault();
    //console.log({ ...allValues });
    //console.log(Object.entries({...allValues}));

    //submit user data on registration api
    if (validateField(allValues)) {
      let URL = SERVICES.REGISTER_API;
      let promise = apiCall(URL, allValues);
      // console.log(promise);
      promise
        .then((result) => {
          console.log(result);
          console.log(JSON.parse(result));
          let response = JSON.parse(result);
          // console.log(result);
          if (response) {
            if (response.status === "failed") {
              toast.success(response.msg, {
                position: toast.POSITION.TOP_CENTER,
              });
            }
            if (response.status === "success") {
              toast.success(response.msg, {
                position: toast.POSITION.TOP_CENTER,
              });

              //remove all value from the input fields

              // setAllValues({username: "",
              // email: "",
              // password: "",
              // confirmPassword: "",
              // country: "",
              // state: "",
              // city: "",
              // food: false,
              // movie: false,})
            }
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
    //console.log("submit");
    //toast.success('User Register Successfully..', { position: toast.POSITION.TOP_CENTER });
  };

  ///create array

  //form validation

  const validateField = ({
    username,
    email,
    password,
    confirmPassword,
    country,
    state,
    city,
    food,
    movie,
  }) => {
    if (!username) {
      toast.warning("User Name is mandatory.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return false;
    }

    if (!email) {
      toast.warning("Email is mandatory.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return false;
    } else {
      let emailValid = email.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
      if (!emailValid) {
        let fieldValidationErrors = emailValid ? "" : " is invalid";
        toast.warning("Email " + fieldValidationErrors, {
          position: toast.POSITION.TOP_CENTER,
        });
        return false;
      }
    }

    if (!password) {
      toast.warning("Password is mandatory.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return false;
    } else {
      let passwordValid = password.length >= 6;
      if (!passwordValid) {
        let validpassword = passwordValid ? "" : " is too short";
        toast.warning("Password " + validpassword, {
          position: toast.POSITION.TOP_CENTER,
        });
        return false;
      }
    }

    // if(confirmPassword){
    //   let cpasswordValid = confirmPassword.length >= 6;
    //   let validcpassword = cpasswordValid ? '': ' is too short';
    //   toast.success('Confirm Password is '+validcpassword,{position: toast.POSITION.TOP_CENTER});
    // }
    if (password !== confirmPassword) {
      toast.warning("Password and confirm password is not matched!! ", {
        position: toast.POSITION.TOP_CENTER,
      });
      return false;
    }
    return true;
  };

  return (
    <div>
      <ToastContainer />
      <h1 className="text1">Registration</h1>
      <div className="container" id="form1">
        <Form>
          <Form.Group className="mb-3" controlId="formBasicName">
            <Form.Label>User Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter Name"
              value={allValues.username}
              onChange={handleChange}
              name="username"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              value={allValues.email}
              onChange={handleChange}
              name="email"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              value={allValues.password}
              onChange={handleChange}
              name="password"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicConfirmPassword">
            <Form.Label>Confirm Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Confirm Password"
              value={allValues.confirmPassword}
              onChange={handleChange}
              name="confirmPassword"
            />
          </Form.Group>
          <Form.Select
            aria-label="Default select example"
            value={allValues.country}
            onChange={handleChange}
            name="country"
          >
            <option>Select Country</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </Form.Select>{" "}
          <br />
          <Form.Select
            aria-label="Default select example"
            value={allValues.state}
            onChange={handleChange}
            name="state"
          >
            <option>Select State</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </Form.Select>{" "}
          <br />
          <Form.Select
            aria-label="Default select example"
            value={allValues.city}
            onChange={handleChange}
            name="city"
          >
            <option>Select City</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </Form.Select>
          <br />
          <Form.Group className="mb-3" controlId="formBasicCheckbox">
            <Form.Check
              type="checkbox"
              label="Food" //{`Food-${isFoodChecked}`}
              value={!isFoodChecked ? "food" : ""}
              // value= {isFoodChecked ? '':'checked'}
              onChange={handleChange}
              name="food"
              checked={isFoodChecked}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicCheckbox">
            <Form.Check
              type="checkbox"
              label="Movie" //{`Movie-${isMovieChecked}`}
              value={!isMovieChecked ? "movie" : ""}
              onChange={handleChange}
              name="movie"
              checked={isMovieChecked}
              // {isMovieChecked ? '':'checked'}
            ></Form.Check>
          </Form.Group>
          <Button
            variant="primary"
            type="submit"
            id="registration-submit"
            onClick={handleSubmit}
          >
            Submit
          </Button>
        </Form>
        {/* <div className="GeeksforGeeks">
            <button onClick={notify}>Click Me!</button>
            </div> */}

        <Link to="/login">
          Already Registered<span> Login..</span>{" "}
        </Link>
      </div>
    </div>
  );
};

export default RegistrationForm;
