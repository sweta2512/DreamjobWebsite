import { BrowserRouter, Routes,Link ,Route } from "react-router-dom"; 
import Registration from './registration/Registration.jsx';
import Login from './login/Login';





let RoutePath =()=>{
    return(
        <div>
            <Registration/>
           {/* <Login/> */}


        </div>
    )
}

export default RoutePath;