
import React, { useState } from "react";
import Child from './Child';

const Parent = () =>{
    const [name, setName] = useState(0);
  
    const handleCallback = (childData) =>{
        setName(childData)
    }
  
    return(
        <div>
            <Child parentCallback = {handleCallback}/>
            {name}
        </div>
    )
  }

  export default Parent;