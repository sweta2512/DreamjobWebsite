const Services = {
     COUNTRY_LIST: 'https://api.first.org/data/v1/countries',
     REGISTER_API: 'http://127.0.0.1:8000/api/user',
     LOGIN_API: 'http://127.0.0.1:8000/api/login',
}

export default Services;

