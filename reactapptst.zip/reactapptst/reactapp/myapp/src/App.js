import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Link, Route } from "react-router-dom";
import RoutePath from './componenets/index.js';
import Login from './componenets/login/Login';
import Logout from './componenets/logout/Logout';

function App() {
  return (
    <div className="App">
      <Logout/>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<RoutePath />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
