<?php
session_start();
require_once('config.php');
if (isset($_COOKIE['user'])) {
    header("location: dashboard.php");
    echo "sfhshf";
}
?>

<!DOCTYPE html>
<html>

<head></head>

<body>
    <h1><?php if (isset($_SESSION['reg_msg'])) {
            $msg = $_SESSION['reg_msg'];
            echo  $msg;
        } ?></h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        email:<input type="email" name="email" required></br>
        password:<input type="password" name="pass" required><br>

        <button type="submit" name="login">Login</button>


    </form>
    <div><button> <a href="registrationform.php">New user register here...</a></button></div>
    <div> <a href="forgotpassword.php">Forgot Password...</a>
        <form method="post" action="send_link.php">
            <p>Enter Email Address To Send Password Link</p>
            <input type="text" name="email">
            <input type="submit" name="submit_email">
        </form>

        <!--  -->
        <!-- <form action="password-reset-token.php" method="post">
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp">
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <input type="submit" name="password-reset-token" class="btn btn-primary">
        </form> -->



    </div>
</body>

</html>
<?php
if ($_SERVER["REQUEST_METHOD"] === 'POST') {
    if (!empty($_REQUEST['email']) && !empty($_REQUEST['pass'])) {

        $email = $_REQUEST['email'];
        $password = sha1($_REQUEST['pass']);
        $sql = "SELECT `id`, `name`, `email`, `password`, `cpassword` FROM `session` WHERE email='$email' && password= '$password'";
        //echo$sql;
        $user_detail = mysqli_fetch_array(mysqli_query($conn, $sql), MYSQLI_ASSOC);

        if ($user_detail) {

            //print_r( $user_detail);
            $_SESSION["username"] = $user_detail['name'];
            //echo $_SESSION["username"];

            $cookie_value = $_SESSION["username"];
            setcookie("user", $cookie_value, time() + (86400 * 30));
            header("location: dashboard.php");
        } else {
            echo "Your Login Name or Password is invalid";
        }
    }
}


?>