<?php
session_start();
if(isset($_SESSION["username"],$_COOKIE['user'])){
    unset($_SESSION["username"]);
    setcookie('user', null, time() - 3600);
    unset($_COOKIE['user']); 
    
}
// if (isset($_COOKIE['user'])) {
//     setcookie('user', null, time() - 3600);
//     unset($_COOKIE['user']);    
// } 
session_destroy();
header("Location: login.php");
die;
