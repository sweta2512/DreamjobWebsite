<?php
session_start();
if(isset($_COOKIE['user'])){
    $_SESSION["username"]=$_COOKIE['user'];
}
if(isset($_SESSION["username"])){
 echo $_SESSION["username"];
}else{
    header("location: login.php");
    die;
}

?>


<!DOCTYPE html>
<html>
    <head><title>dashboard</title></head>
    <body>
        <h1>Welcome</h1>
        <h4><a href="menu.php">User Menu</a></h4>
        <h2><a href = "logout.php">Sign Out</a></h2>
    </body>
</html>