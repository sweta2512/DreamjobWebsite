<?php
session_start();
if(isset($_COOKIE['user'])){
    $_SESSION["username"]=$_COOKIE['user'];
}
if(isset($_SESSION["username"])){
 echo $_SESSION["username"];
}else{
    header("location: login.php");
    die;
}


?>