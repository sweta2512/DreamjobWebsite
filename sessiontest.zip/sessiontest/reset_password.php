<?php
session_start();
require_once('config.php');
if (isset($_COOKIE['user'])) {
    header("location: dashboard.php");
    echo "sfhshf";
}
//print_r($_POST);
$email = $_POST['email'];
$old_password = $_POST['old_password'];
$new_password = $_POST['new_password'];
$confirm_password = $_POST['confirm_password'];
if ($new_password === $confirm_password) {
    $get_old_password = "SELECT `old_password` FROM `password` WHERE id='$email' order by password_id desc limit 5";
    echo $get_old_password;
    $old_password1 = mysqli_query($conn, $get_old_password);
    // print_r($old_password1);
    $pass_old = [];
    while ($row = mysqli_fetch_array($old_password1, MYSQLI_ASSOC)) {
        echo "<br>" . $row['old_password'];
        $pass_old[] = $row['old_password'];
    }
    print_r($pass_old);
    if (in_array($new_password, $pass_old)) {
        die('already used');
    } else {
        $user_table = " UPDATE `session` SET `password`='$new_password',`cpassword`='$confirm_password' WHERE email='$email' ";
        mysqli_query($conn, $user_table);
        $password_table = "UPDATE `password` SET`new_password`='$new_password' WHERE id ='$email'&& old_password='$old_password' ";
        mysqli_query($conn, $password_table);
    }
} else {
    echo "password and confirm password not match";
}
