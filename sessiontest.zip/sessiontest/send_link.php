<?php
session_start();
require_once('config.php');
if (isset($_COOKIE['user'])) {
    header("location: dashboard.php");
    echo "sfhshf";
}

if (isset($_POST['submit_email']) && $_POST['email']) {
    print_r($_POST);
    $email = $_POST['email'];
    //get old password
    $sql = "SELECT `email`,`password` FROM `session` WHERE email='$email' ";
    $data = mysqli_fetch_array(mysqli_query($conn, $sql), MYSQLI_ASSOC);
    $emailId = $data['email'];
    $pass = $data['password'];
    print_r($pass);
    //generate token

    $token = md5($emailId) . rand(10, 9999);
    //expiry 
    $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
    $expDate = date("Y-m-d H:i:s", $expFormat);
    //echo $expDate;
    //////// 

    $set_old_password = "INSERT INTO `password`(`password_id`, `old_password`, `new_password`, `id`) VALUES ('','$pass','$pass','$emailId')";
    //mysqli_query($conn, $set_old_password);
    echo $set_old_password;
    if(mysqli_query($conn, $set_old_password)){
        //die('sfjhdhsjdg')
        echo"saved in password table";
    }else{
       // die('error');
    }
    
    $get_old_password = "SELECT `id`,`old_password` FROM `password` WHERE id='$email' order by password_id desc limit 5";
    $old_password = mysqli_fetch_assoc(mysqli_query($conn, $get_old_password));
    print_r($old_password);
}
?>

    <h1>Enter your new password here....</h1>
    <form method="post" action="reset_password.php">
        <input type="hidden" name="email" value="<?php
                                                    if (!empty($old_password['id'])) {
                                                        echo $old_password['id'];
                                                    } elseif (!empty($emailId)) {
                                                        echo $emailId;
                                                    }
                                                    ?>">
        <input type="hidden" name="old_password" value="<?php
                                                        if (!empty($old_password['old_password'])) {
                                                            echo $old_password['old_password'];
                                                        } elseif (!empty($pass)) {
                                                            echo $pass;
                                                        }
                                                        ?>">
        New Password:<input type="password" name="new_password">
        Confirm Password:<input type="password" name="confirm_password">
        <input type="submit" name="submit_reset_password">
    </form>

<?php

    ///////


   // $update = mysqli_query($conn, "UPDATE users set  password='" . $pass . "', reset_link_token='" . $token . "' ,exp_date='" . $expDate . "' WHERE email='" . $emailId . "'");










    //create reset link





    //$link = "<a href='www.yourwebsite.com/reset-password.php?key=".$emailId."&token=".$token."'>Click To Reset password</a>";




?>