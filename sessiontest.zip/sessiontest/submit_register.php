<?php
session_start();
require_once('config.php');

if ($_SERVER["REQUEST_METHOD"] === 'POST') {
    if (isset($_REQUEST['submit'])) {
        // print_r($_REQUEST);
        $name = trim($_REQUEST['name']);
        $email = $_REQUEST['email'];
        $password = sha1($_REQUEST['password']);
        $confirm_password = sha1($_REQUEST['confirm_Password']);

        if (!empty($name) && !empty($email) && !empty($password) && !empty($confirm_password)) {
            if ($password === $confirm_password) {
                $sql = "INSERT INTO `session`(`id`, `name`, `email`, `password`, `cpassword`) VALUES ('','$name' ,'$email','$password','$confirm_password')";
                //echo $sql;
                if (mysqli_query($conn, $sql)) {
                    // $sql1 = "SELECT `email`,`password` FROM `session` WHERE email='$email' ";
                    // $data = mysqli_fetch_array(mysqli_query($conn, $sql1), MYSQLI_ASSOC);

                    // $email1 = $data['email'];
                    // $pass = $data['password'];
                    // $sql = "INSERT INTO `password`(`password_id`, `password`, `id`) VALUES ('','$pass','$email1')";
                    // mysqli_query($conn, $sql);
                    // $_SESSION['msg'] = $pass;
                    $_SESSION['msg'] = "USER REGISTERED SUCCESSFULLY.";
                    header("location: registrationform.php");
                } else {

                    $_SESSION['msg'] = "USER NOT REGISTERED.";
                    header("location: registrationform.php");
                }
            } else {
                $_SESSION['msg'] = "Password and Confirm Password does not match";
                header("location: registrationform.php");
            }
        } else {
            $_SESSION['msg'] = "All fields are mandatory";
            header("location: registrationform.php");
        }
    }
}
