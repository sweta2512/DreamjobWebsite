<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\Models\Newuser;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

class NewuserController extends Controller
{
    //
    public function __construct()
    {
        $this->apiToken = uniqid(base64_encode(Str::random(40)));
    }

    //register user
    public function register(Request $request)
    {
        try {
            //dd($request);
            //return $request->all();

            // $validateData = $request->validate([
            //     'username' => 'required',//regex:/^[a-z A-Z]+$/u'
            //     'email' => 'required|email',
            //     'password' => 'required|min:6|max:12',
            //     'confirm_password' => 'required|same:password',
            //     //'mobile' => 'numeric|required|digits:10'
            // ]);

            $validator = Validator::make($request->all(), [
                'username' => 'required',
                'email' => 'required|email',
                'password' => 'required',
                'confirmPassword' => 'required',
            ]);
            //check user already exist else register

            if (Newuser::where('email', $request->email)->exists()) {
                //email exists in user table
                return response()->json([
                    'status' => 'failed',
                    'msg' => 'Email already Exist..Please use another email'
                ]);
            } else {
                //$input = $request->all();
                // Newuser::create([
                //         'name' => $request->username,
                //         'email' =>$request->email,
                //         'password' => Hash::make($request->password),
                //         'confirm_password' => Hash::make($request->confirmPassword),
                //         'gender' =>null,
                //         'food' =>$request->food,
                //         'movie' =>$request->movie
                //       ]);

                $user = new Newuser;
                $user->name = $request->username;
                $user->email = $request->email;
                $user->password = Hash::make($request->password);
                $user->confirm_password = Hash::make($request->confirmPassword);
                $user->gender = null;
                $user->food = $request->food;
                $user->movie = $request->movie;
                $user->save();
                $token = $this->apiToken;
                return response()->json([
                    'status' => 'success',
                    'msg' => 'User Registered Successfully....',
                    'token' => $token,
                ]);
            }
            // print_r($res);


            // return $request;
        } catch (\Exception $e) {
            //return 'data is invalid';
            return $e->getMessage();
        }
    }

    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required',
            ]);

            // $credentials = $request->only('email', 'password');
            $credentials = [
                'email' => $request->email,
                'password' => $request->password
            ];
            // return $request->all();
    
            if ($validator->fails())
            {
                return response(['errors'=>$validator->errors()->all()], 422);
            }

            $user = Newuser::where('email', $request->email)->first();

            if ($user) {
                if (Hash::check($request->password, $user->password)) {//the check method compares the plain-text with the hashedPassword variable and if the result is true, it returns a true value.
                    // $token = $user->createToken('Laravel Password Grant Client')->accessToken;
                    // $response = ['token' => $token];
                    // return response($response, 200);
                    return response()->json([
                                'status' => 200,
                                'msg' => 'You are logged IN successfully..',
                                'user'=>  $user->name,
                            ]);
                } else {
                    return response()->json([
                        'status' => 404,
                        'msg' => 'Your Password is Incorrect. Please correct it and try again..',
                    ]);
                }
            } else {
                $response = ["message" =>'User does not exist'];
                return response()->json([
                    'status' => 404,
                    'msg' => 'User does not exist.',
                ]);
            }

            // return response()->json([
            //     'status' => 404,
            //     'msg' => 'Try Again with vaild credentials..',
            // ]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
}
