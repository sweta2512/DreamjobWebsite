function fun(){
    console.log('inside fun function');
}

fun();
async function fetchUserDetails(userId) {
    // pretend we make an asynchronous call
   // and return the user details
   return {'name': 'Robin', 'likes': ['toys', 'pizzas']};
}
console.log(fetchUserDetails());

let promise = new Promise(function(resolve,reject){
    console.log('inside promise executor');
    resolve('inside resolve');
})

fun();

promise.then((result)=>{// will take time
    console.log('inside then'+result);
})
fun();

fetchUserDetails().then((result)=>{//will take time
    console.log(result)
})
console.log(fetchUserDetails(2));
fun();


//
// (async () => {
//     const user = await fetchUserDetails();
//  })()




////////////////Error Handling/////////////////////

const validateUser = ({userId, password}) => {//variable destructuring {userId, password} in js
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (userId && password) {
                resolve(`${userId} you have been authenticated successfully!!!`);
            } else {
                reject({message: 'userId or Password could be blank!'});
            }

        }, 2000);
    });
}


const app = async () => {
    const data = {
        userId: 'sweta@chetu.com',
        password: '1234'
    };

    try {
        console.log('Initializing...');
        const result = await validateUser(data); //will take time 2 sec
        console.log(result);
        const result1 = await validateUser(data); //will take time 2 sec after first await
        console.log('result1 '+result1);
    } catch (e) {
        console.error(e.message);
    }
}

app();

//////using loop with async/await


const users = ['saviomartin', 'victoria-lo', 'max-programming', 'atapas'];

const fetchData = user => {
    return fetch(`https://api.github.com/users/${user}`);
}
//console.log(fetchData());

const loopFetches = () => {
    for (let i = 0; i < users.length; i++) {
        console.log(`*** Fetching details of ${users[i]} ***`);
        const response = fetchData(users[i]);
        response.then(response => {
            response.json().then(user => {
                console.log(`${user.name} is ${user.bio} has ${user.public_repos} public repos and ${user.followers} followers`);
            });
        });
    }
}

//loopFetches();

const loopFetchesAsync = async () => {
    for (let i = 0; i < users.length; i++) {
        console.log(`=== Fetching details of ${users[i]} ===`);
        const response = await fetchData(users[i]);
        const user = await response.json();            
        console.log(`${user.name} is ${user.bio} has ${user.public_repos} public repos and ${user.followers} followers`);
    }
}
loopFetchesAsync();



///////////merge object


let person = {
    firstName: 'John',
    lastName: 'Doe',
    age: 25,
    ssn: '123-456-2356',
    contact: {
        phone: '408-989-8745',
        email: 'john.doe@example.com'
    }
};


let job = {
    jobTitle: 'JavaScript Developer',
    location: 'USA'
};

let employee = { ...person,  ...job };
console.log(employee);