function fun() {
  console.log("fun1");
}
fun();
function fun1() {
  console.log("fun1111");
}
let promise = new Promise((resolve, reject) => {
  let a = true;
  if (a) {
    resolve("got water");
  } else {
    reject("fell down");
  }
});

console.log(promise);
const grandParentsCooking = () => {
  promise.then((result) => {
    console.log(`cooking with ${result}`);
  });
  promise.catch((err) => [console.log(` ${err}`)]);
};
const grandParentsCooking1 = () => {
  promise.then((result) => {
    console.log(`cooking1 with ${result}`);
  });
  promise.catch((err) => [console.log(` ${err}`)]);
};

// grandParentsCooking();
// grandParentsCooking1();

// fun();

// grandParentsCooking1();
// fun1();
// fun();

//////////

function getPromise(URL) {
  let promise = new Promise((resolve, reject) => {
    let req = new XMLHttpRequest();
    console.log(req);
    req.open("get", URL);
    req.onload = () => {
      if (req.status === 200) {
        resolve(req.response);
      } else {
        reject("There is an Error!");
      }
    };
    req.send();
  });
  return promise;
}
const ALL_POKEMONS_URL = "https://pokeapi.co/api/v2/pokemon?limit=50";
//.log(getPromise( ALL_POKEMONS_URL));
let promise1 = getPromise(ALL_POKEMONS_URL);
let consumer = () => {
  promise1.then(
    (result) => {
      let result1 = JSON.parse(result).results;
      let ele = document.getElementById("ele");
      let table = document.createElement("table");
      table.innerHTML = "<tr><th>Name</th><th>'URL'</th></tr>";
      result1.forEach((element) => {
        // console.log(element);
        table.innerHTML += `<tr><td>${element.name}</td><td>${element.url}</td></tr>`;
      });
      ele.appendChild(table);
      //console.log(table);
    },
    (error) => {
      console.log(error);
    }
  );
};
consumer();
