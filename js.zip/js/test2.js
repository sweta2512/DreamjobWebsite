///alert('helloooooo')
// document.getElementById("clickme").onload=function(event){
//   alert('hiiiii')
// }
debugger;
window.onload = (event) => {
  debugger;
  console.log('page is fully loaded');

  
};
debugger;
var clickme = document.getElementById("clickme");
debugger;
list = document.getElementsByClassName("list");
 list1 =document.querySelectorAll('.list');
var listnew = collectionToArray(list);
// console.log(clickme);
// console.log(list);
// console.log(list1)
// list = collectionToArray(list);
// console.log(list);
debugger;
clickme.addEventListener('load',(event) => {
  debugger;
  console.log("Logo has been loaded!");
});
// /This code looks simple enough. When I click on the button, all divs with class list are supposed to disappear. Unfortunately, when I run the code, I get an error.

// Uncaught TypeError: Cannot set property 'className' of undefined

// The problem is getElementsByTagName returns an HTMLCollection not an Array. And this collection is live, it updates as the values change on the DOM.

setTimeout(function () {
  var el = document.createElement("div");
  el.textContent = "hiiiiiiiiiii";
  el.className = "list";
  clickme.append(el);
  console.log(list);

  listnew = collectionToArray(list);
  console.log(listnew);
}, 3000);

clickme.onclick = function () {
  var i,
    l = listnew.length;
  for (i = 0; i < l; i++) {
    listnew[i].className = "hide";
    console.log(i);
    console.log(listnew);
  }
};

function collectionToArray(collection) {
  var i, length = collection.length, array = [];
  for (i = 0; i < length; i++) {
    array.push(collection[i]);
  }
  return array;
}





function appendDefaultDiv(){
    var divElement = document.createElement('div') ;

    divElement.className = 'foo';
    divElement.innerHTML = "Some Text";

    return divElement;
}


document.body.appendChild(appendDefaultDiv());


///////////////

// new Promise(function(resolve, reject) {

//   setTimeout(() => resolve(1), 1000); // (*)

// }).then(function(result) { // (**)

//   alert(result); // 1
//   console.log('resolve2')
//   return result * 2;

// }).then(function(result) { // (***)

//   alert(result); // 2
//   console.log('resolve3')
//   return result * 2;

// }).then(function(result) {

//   alert(result); // 4
//   console.log('resolve4')
//   return result * 2;

// });